package ex02_강승훈;

public class Account {
	
	//필드 : 잔고 balance
	
	
}
