package ex03_강승훈;

public interface StringInter {

}
