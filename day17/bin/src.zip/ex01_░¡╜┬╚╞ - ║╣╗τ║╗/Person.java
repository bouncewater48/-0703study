package ex01_강승훈;

public abstract class Person {
	
	//필드 : 이름, 나이(접근제한자 private)
	//생성자 : 매개변수 모두 받는 생성자(접근제한자 public)
	//점수계산메소드(접근제한자 public, 메소드명 score) => 점수가 없습니다 출력
	
//	private void name() {
//		System.out.println("강승훈");
//	}
//	private void age() {
//		System.out.println(27);
//	}
//	
//	public void score(name + age,"강승훈",27);
	
//	String name;
//	int age;
	
	public void score() {
	}
	
	
	
	
	
}
