package ex01_강승훈;

public interface InterA {


}
