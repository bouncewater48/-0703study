package review;

public class Task02 {
	public static void main(String[] args) {
		
	}
}
